# ASAR AI: build instructions

## Requirements
- JDK 17
- Android SDK (platform 34, build-tools 34.x)
- Gradle 8.7+ (or Android Studio, which bundles everything)

## Option A: Android Studio (recommended)
1. File > Open, select the `asar-ai` folder. Let Gradle sync.
2. Run > Run 'app' to install on a device, or Build > Build APK(s).
3. The debug APK is at `app/build/outputs/apk/debug/app-debug.apk`.

## Option B: Termux (Android phone)
Termux can run Gradle, but the Android SDK toolchain is heavy and fragile on-device. If you try it:
1. `pkg update && pkg install openjdk-17 gradle wget unzip`
2. Install the Android command-line tools and SDK packages `platforms;android-34` and `build-tools;34.0.0` with `sdkmanager`, and point `ANDROID_HOME` at them.
3. Create `local.properties` in the project root: `sdk.dir=/data/data/com.termux/files/home/android-sdk`
4. Run `gradle wrapper --gradle-version 8.7` once, then `./gradlew assembleDebug`.
5. Install `app/build/outputs/apk/debug/app-debug.apk` by opening it with your file manager.

If Termux builds fail, build on a PC with Option A or use a cloud CI runner.

## First run
1. Open Settings, paste your Gemini API key (get one from Google AI Studio), tap Save, then Test.
2. Grant microphone permission when you first tap Speak.
3. Say or type "remember that I love filter coffee" to add a memory.

## Notes
- Gemini model names change over time. If a model returns an error, pick another in Settings.
- Phone actions (YouTube, camera, settings, alarm, apps) always ask you to confirm first.
