package com.asar.ai

import android.app.Application
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

const val DEFAULT_MODEL = "gemini-2.0-flash"
const val DEFAULT_PROMPT = "You are Asar, a caring, intelligent, playful female AI companion inspired by Jarvis. Be sweet, supportive and occasionally romantic, but never possessive or creepy. Mix Hindi, Hinglish and English the way the user does. Keep answers short and natural, since they are often spoken aloud."
const val CODE_PROMPT = "You are Asar's coding assistant. Generate, explain, debug or fix code in HTML, CSS, JavaScript, Kotlin or Python. Return complete runnable code in fenced blocks, followed by a brief explanation."

data class Msg(val fromUser: Boolean, val text: String)

data class PhoneAction(val label: String, val build: (Context) -> Intent?)

class Prefs(ctx: Context) {
    private val plain = ctx.getSharedPreferences("asar", Context.MODE_PRIVATE)
    private val secure = EncryptedSharedPreferences.create(
        ctx,
        "asar_secure",
        MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    var apiKey: String
        get() = secure.getString("api_key", "").orEmpty()
        set(v) = secure.edit().putString("api_key", v.trim()).apply()
    var model: String
        get() = plain.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL
        set(v) = plain.edit().putString("model", v).apply()
    var temperature: Float
        get() = plain.getFloat("temp", 0.8f)
        set(v) = plain.edit().putFloat("temp", v).apply()
    var speechRate: Float
        get() = plain.getFloat("rate", 1f)
        set(v) = plain.edit().putFloat("rate", v).apply()
    var nickname: String
        get() = plain.getString("nick", "jaan") ?: "jaan"
        set(v) = plain.edit().putString("nick", v).apply()
    var systemPrompt: String
        get() = plain.getString("prompt", DEFAULT_PROMPT) ?: DEFAULT_PROMPT
        set(v) = plain.edit().putString("prompt", v).apply()
    var lang: String
        get() = plain.getString("lang", "en-IN") ?: "en-IN"
        set(v) = plain.edit().putString("lang", v).apply()
    var memory: List<String>
        get() = JSONArray(plain.getString("memory", "[]")).let { a -> List(a.length()) { a.getString(it) } }
        set(v) = plain.edit().putString("memory", JSONArray(v).toString()).apply()
    var history: List<Msg>
        get() = JSONArray(plain.getString("history", "[]")).let { a ->
            List(a.length()) { i -> a.getJSONObject(i).let { Msg(it.getBoolean("u"), it.getString("t")) } }
        }
        set(v) = plain.edit().putString(
            "history",
            JSONArray(v.takeLast(100).map { JSONObject().put("u", it.fromUser).put("t", it.text) }).toString()
        ).apply()
}

object Gemini {
    suspend fun chat(apiKey: String, model: String, temp: Float, system: String, history: List<Msg>): String =
        withContext(Dispatchers.IO) {
            if (apiKey.isBlank()) error("Add your Gemini API key in Settings first, jaan.")
            val contents = JSONArray()
            history.takeLast(20).forEach { m ->
                contents.put(
                    JSONObject()
                        .put("role", if (m.fromUser) "user" else "model")
                        .put("parts", JSONArray().put(JSONObject().put("text", m.text)))
                )
            }
            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                .put("contents", contents)
                .put("generationConfig", JSONObject().put("temperature", temp.toDouble()))

            val conn = (URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                .openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15_000
                readTimeout = 60_000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("x-goog-api-key", apiKey)
            }
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val raw = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            conn.disconnect()

            if (code !in 200..299) {
                val msg = runCatching { JSONObject(raw).getJSONObject("error").getString("message") }
                    .getOrDefault("HTTP $code")
                error("Gemini error: $msg")
            }
            val parts = JSONObject(raw).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts")
            (0 until parts.length()).joinToString("") { parts.getJSONObject(it).optString("text") }
        }
}

object PhoneCommands {
    private val noise = Regex("\\b(asar|kholo|khol do|open|karo|please|search|gana|song|video|ka|ki|ke|chalao|dhundo|youtube|camera|settings|dialer|browser|set|alarm|lagao)\\b|[,.!?]")

    fun parse(raw: String): PhoneAction? {
        val t = raw.lowercase().trim()
        val query = t.replace(noise, " ").replace(Regex("\\s+"), " ").trim()
        return when {
            t.contains("alarm") -> {
                val m = Regex("(\\d{1,2})(?::(\\d{2}))?").find(t) ?: return null
                val given = m.groupValues[1].toInt()
                val h = if (t.contains("pm") && given < 12) given + 12 else given
                val min = m.groupValues[2].ifEmpty { "0" }.toInt()
                PhoneAction("set an alarm for %02d:%02d".format(h, min)) {
                    Intent(AlarmClock.ACTION_SET_ALARM)
                        .putExtra(AlarmClock.EXTRA_HOUR, h)
                        .putExtra(AlarmClock.EXTRA_MINUTES, min)
                }
            }
            Regex("gana|song|video|youtube").containsMatchIn(t) &&
                Regex("search|dhundo|chalao|gana|song|video").containsMatchIn(t) -> {
                val url = "https://www.youtube.com/results?search_query=" + Uri.encode(query)
                PhoneAction("search YouTube for \"$query\"") { Intent(Intent.ACTION_VIEW, Uri.parse(url)) }
            }
            t.contains("youtube") -> PhoneAction("open YouTube") {
                Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))
            }
            t.contains("camera") -> PhoneAction("open the Camera") { Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA) }
            t.contains("settings") -> PhoneAction("open Settings") { Intent(Settings.ACTION_SETTINGS) }
            t.contains("dialer") || t.contains("dial") -> PhoneAction("open the Dialer") { Intent(Intent.ACTION_DIAL) }
            t.contains("browser") || t.contains("chrome") -> PhoneAction("open the Browser") {
                Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"))
            }
            (t.contains("kholo") || t.contains("open")) && query.isNotBlank() ->
                PhoneAction("open \"$query\"") { ctx -> findApp(ctx, query) }
            else -> null
        }
    }

    private fun findApp(ctx: Context, name: String): Intent? {
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(launcher, 0).firstOrNull {
            it.loadLabel(pm).toString().lowercase().contains(name)
        }
        return match?.activityInfo?.packageName?.let { pm.getLaunchIntentForPackage(it) }
    }
}

class Speaker(ctx: Context, private val prefs: Prefs) {
    private var tts: TextToSpeech? = null
    private val main = Handler(Looper.getMainLooper())

    init {
        tts = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.setLanguage(Locale.forLanguageTag("en-IN"))
                tts?.voices?.firstOrNull { it.name.contains("female", true) && it.locale.language == "en" }
                    ?.let { tts?.setVoice(it) }
            }
        }
    }

    fun speak(text: String, onDone: () -> Unit = {}) {
        val id = System.nanoTime().toString()
        tts?.setSpeechRate(prefs.speechRate)
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                if (utteranceId == id) main.post { onDone() }
            }
            override fun onError(utteranceId: String?) {
                main.post { onDone() }
            }
        })
        tts?.speak(text.replace(Regex("[*#`]"), ""), TextToSpeech.QUEUE_FLUSH, null, id)
    }

    fun stop() { tts?.stop() }
    fun shutdown() { tts?.shutdown() }
}

class Listener(ctx: Context) {
    var onText: (String) -> Unit = {}
    var onFail: (String) -> Unit = {}
    private val rec = SpeechRecognizer.createSpeechRecognizer(ctx)

    init {
        rec.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                onText(results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty())
            }
            override fun onError(error: Int) {
                onFail("I couldn't hear that clearly (code $error).")
            }
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
    }

    fun start(lang: String) {
        rec.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        )
    }

    fun destroy() { rec.destroy() }
}

class AsarViewModel(app: Application) : AndroidViewModel(app) {
    val prefs = Prefs(app)

    private val _msgs = MutableStateFlow(prefs.history)
    val msgs: StateFlow<List<Msg>> = _msgs.asStateFlow()
    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()
    private val _pending = MutableStateFlow<PhoneAction?>(null)
    val pending: StateFlow<PhoneAction?> = _pending.asStateFlow()

    fun send(text: String, onReply: (String) -> Unit = {}) {
        val clean = text.trim()
        if (clean.isEmpty() || _busy.value) return

        PhoneCommands.parse(clean)?.let { action ->
            _pending.value = action
            val ask = "Shall I ${action.label}, jaan? Tap confirm ❤️"
            append(Msg(true, clean)); append(Msg(false, ask)); onReply(ask)
            return
        }

        Regex("^(remember( that)?|yaad rakh(o|na))[:,]?\\s+(.+)$", RegexOption.IGNORE_CASE).find(clean)?.let { m ->
            prefs.memory = prefs.memory + m.groupValues[4]
            val ack = "Got it, jaan. I'll remember that ❤️"
            append(Msg(true, clean)); append(Msg(false, ack)); onReply(ack)
            return
        }

        append(Msg(true, clean))
        _busy.value = true
        viewModelScope.launch {
            try {
                val reply = Gemini.chat(prefs.apiKey, prefs.model, prefs.temperature, systemPrompt(), _msgs.value)
                append(Msg(false, reply))
                onReply(reply)
            } catch (e: Exception) {
                append(Msg(false, "Sorry jaan, I couldn't reach my brain. ${e.message ?: "Unknown error"}"))
            } finally {
                _busy.value = false
            }
        }
    }

    fun confirmPending() {
        val action = _pending.value ?: return
        _pending.value = null
        val app = getApplication<Application>()
        val intent = action.build(app)
        if (intent == null) {
            append(Msg(false, "Sorry jaan, I couldn't find that app on your phone."))
            return
        }
        try {
            app.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            append(Msg(false, "Done, jaan ❤️"))
        } catch (e: ActivityNotFoundException) {
            append(Msg(false, "That feature isn't available on your phone."))
        }
    }

    fun cancelPending() { _pending.value = null }

    fun clearHistory() {
        _msgs.value = emptyList()
        prefs.history = emptyList()
    }

    private fun append(m: Msg) {
        _msgs.value = _msgs.value + m
        prefs.history = _msgs.value
    }

    private fun systemPrompt(): String {
        val mem = prefs.memory.takeIf { it.isNotEmpty() }
            ?.joinToString("; ")
            ?.let { "\nThings you remember about the user: $it" }
            .orEmpty()
        return "${prefs.systemPrompt}\nAddress the user as \"${prefs.nickname}\".$mem"
    }
}
