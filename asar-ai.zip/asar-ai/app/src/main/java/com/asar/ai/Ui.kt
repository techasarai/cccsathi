package com.asar.ai

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

val Neon = Color(0xFFB36BFF)
val Electric = Color(0xFF3D7BFF)
val Cyan = Color(0xFF29E5FF)

private val AsarScheme = darkColorScheme(
    primary = Neon, secondary = Cyan, tertiary = Electric,
    background = Color.Black, surface = Color(0xFF0B0714),
    onBackground = Color(0xFFEDE7FF), onSurface = Color(0xFFEDE7FF),
    surfaceVariant = Color(0xFF17102A), onSurfaceVariant = Color(0xFFB9AED8)
)

@Composable
fun AsarTheme(content: @Composable () -> Unit) =
    MaterialTheme(colorScheme = AsarScheme, content = content)

@Composable
fun Glass(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier
            .clip(RoundedCornerShape(20.dp))
            .background(Color.White.copy(alpha = 0.06f))
            .border(1.dp, Brush.linearGradient(listOf(Neon.copy(alpha = 0.7f), Cyan.copy(alpha = 0.2f))), RoundedCornerShape(20.dp))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        content = content
    )
}

@Composable
fun Orb(size: Dp = 200.dp) {
    val t = rememberInfiniteTransition(label = "orb")
    val pulse by t.animateFloat(0.93f, 1.07f, infiniteRepeatable(tween(1600), RepeatMode.Reverse), label = "pulse")
    val spin by t.animateFloat(0f, 360f, infiniteRepeatable(tween(7000, easing = LinearEasing), RepeatMode.Restart), label = "spin")
    Canvas(Modifier.size(size).graphicsLayer { scaleX = pulse; scaleY = pulse }) {
        val r = this.size.minDimension / 2f
        val inset = 8.dp.toPx()
        val ring = Size(this.size.width - 2 * inset, this.size.height - 2 * inset)
        drawCircle(brush = Brush.radialGradient(listOf(Cyan.copy(alpha = 0.9f), Electric.copy(alpha = 0.5f), Color.Transparent), center = center, radius = r), radius = r)
        drawCircle(brush = Brush.radialGradient(listOf(Color.White, Cyan.copy(alpha = 0.3f)), center = center, radius = r * 0.4f), radius = r * 0.4f)
        drawArc(color = Neon, startAngle = spin, sweepAngle = 110f, useCenter = false, topLeft = Offset(inset, inset), size = ring, style = Stroke(4.dp.toPx()))
        drawArc(color = Cyan, startAngle = -spin, sweepAngle = 70f, useCenter = false, topLeft = Offset(inset, inset), size = ring, style = Stroke(3.dp.toPx()))
    }
}

@Composable
fun QuickCard(label: String, icon: ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Glass(modifier.clickable(onClick = onClick)) {
        Icon(icon, contentDescription = label, tint = Cyan)
        Text(label, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun HomeScreen(vm: AsarViewModel, go: (Screen) -> Unit) {
    val p = vm.prefs
    val hasKey = p.apiKey.isNotBlank()
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("ASAR AI", style = TextStyle(brush = Brush.horizontalGradient(listOf(Neon, Cyan)), fontSize = 30.sp, fontWeight = FontWeight.Black))
        Text(
            if (hasKey) "● AI online" else "● Add your Gemini key in Settings",
            color = if (hasKey) Cyan else Color(0xFFFFB86B), fontSize = 12.sp
        )
        Orb()
        Text("Hey, I'm Asar ❤️", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text(
            "Hey ${p.nickname}, kaise ho? Aaj main tumhari kya help kar sakti hoon?",
            textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Button(
            onClick = { go(Screen.Voice) }, modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Electric)
        ) { Text("🎙️ Voice Assistant") }
        OutlinedButton(onClick = { go(Screen.Chat) }, modifier = Modifier.fillMaxWidth()) { Text("💬 Text Chat") }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            QuickCard("Coding", Icons.Filled.Build, Modifier.weight(1f)) { go(Screen.Coding) }
            QuickCard("YouTube", Icons.Filled.PlayArrow, Modifier.weight(1f)) { vm.send("YouTube kholo"); go(Screen.Chat) }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            QuickCard("Camera", Icons.Filled.Info, Modifier.weight(1f)) { vm.send("camera kholo"); go(Screen.Chat) }
            QuickCard("Settings", Icons.Filled.Settings, Modifier.weight(1f)) { go(Screen.Settings) }
        }
    }
}

@Composable
fun Bubble(m: Msg) {
    Box(Modifier.fillMaxWidth(), contentAlignment = if (m.fromUser) Alignment.CenterEnd else Alignment.CenterStart) {
        Text(
            m.text,
            modifier = Modifier
                .widthIn(max = 300.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(if (m.fromUser) Electric.copy(alpha = 0.35f) else Color.White.copy(alpha = 0.07f))
                .padding(12.dp)
        )
    }
}

@Composable
fun Confirm(vm: AsarViewModel) {
    val pending by vm.pending.collectAsState()
    pending?.let { a ->
        Glass(Modifier.fillMaxWidth()) {
            Text("Confirm: ${a.label}?", fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { vm.confirmPending() }) { Text("Confirm") }
                TextButton(onClick = { vm.cancelPending() }) { Text("Cancel") }
            }
        }
    }
}

@Composable
fun ChatScreen(vm: AsarViewModel) {
    val msgs by vm.msgs.collectAsState()
    val busy by vm.busy.collectAsState()
    var input by rememberSaveable { mutableStateOf("") }
    val list = rememberLazyListState()
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) list.animateScrollToItem(msgs.size - 1) }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Chat with Asar", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        LazyColumn(Modifier.weight(1f), state = list, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(msgs) { Bubble(it) }
            if (busy) item { Text("Asar is typing… 💭", color = Cyan) }
        }
        Confirm(vm)
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextField(
                value = input, onValueChange = { input = it },
                modifier = Modifier.weight(1f), maxLines = 4,
                placeholder = { Text("Message Asar…") }
            )
            IconButton(onClick = { vm.send(input); input = "" }, enabled = !busy && input.isNotBlank()) {
                Icon(Icons.Filled.Send, contentDescription = "Send", tint = Neon)
            }
        }
    }
}

@Composable
fun VoiceScreen(vm: AsarViewModel) {
    val ctx = LocalContext.current
    val msgs by vm.msgs.collectAsState()
    val busy by vm.busy.collectAsState()
    var listening by remember { mutableStateOf(false) }
    var speaking by remember { mutableStateOf(false) }
    var continuous by rememberSaveable { mutableStateOf(false) }
    var heard by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }

    val speaker = remember { Speaker(ctx, vm.prefs) }
    val listener = remember { Listener(ctx) }
    listener.onFail = { listening = false; note = it }
    listener.onText = { text ->
        listening = false
        if (text.isNotBlank()) {
            heard = text
            vm.send(text) { reply ->
                speaking = true
                speaker.speak(reply) {
                    speaking = false
                    if (continuous) { listening = true; listener.start(vm.prefs.lang) }
                }
            }
        }
    }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) { note = ""; listening = true; listener.start(vm.prefs.lang) }
        else note = "I need microphone permission to hear you, jaan 🎤"
    }
    DisposableEffect(Unit) { onDispose { listener.destroy(); speaker.shutdown() } }
    val lastReply = msgs.lastOrNull { !it.fromUser }?.text

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Voice Assistant", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Orb(160.dp)
        Text(
            when {
                listening -> "Listening… 👂"
                speaking -> "Speaking… 💗"
                busy -> "Thinking… 💭"
                else -> "Tap and talk to me, jaan"
            }
        )
        if (heard.isNotBlank()) Text("You: $heard", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Button(onClick = { micPermission.launch(Manifest.permission.RECORD_AUDIO) }, enabled = !listening && !busy) {
            Text(if (listening) "Listening…" else "🎤 Speak")
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = { speaker.stop(); speaking = false }) { Text("Stop speaking") }
            Switch(checked = continuous, onCheckedChange = { continuous = it })
            Text("Continuous")
        }
        Confirm(vm)
        lastReply?.let { Glass(Modifier.fillMaxWidth()) { Text(it) } }
        if (note.isNotBlank()) Text(note, color = Color(0xFFFFB86B))
    }
}

@Composable
fun CodingScreen(vm: AsarViewModel, back: () -> Unit) {
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    var prompt by rememberSaveable { mutableStateOf("") }
    var output by rememberSaveable { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = back) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") }
            Text("Coding Assistant", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Text("Generate, explain, debug or fix code: HTML, CSS, JS, Kotlin, Python.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
        OutlinedTextField(
            value = prompt, onValueChange = { prompt = it },
            modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp),
            placeholder = { Text("e.g. Python script to rename all .txt files") }
        )
        Button(
            enabled = !busy && prompt.isNotBlank(),
            onClick = {
                busy = true
                scope.launch {
                    output = try {
                        Gemini.chat(vm.prefs.apiKey, vm.prefs.model, 0.2f, CODE_PROMPT, listOf(Msg(true, prompt)))
                    } catch (e: Exception) {
                        "Error: ${e.message}"
                    }
                    busy = false
                }
            }
        ) { Text(if (busy) "Working…" else "Generate / Fix") }
        if (output.isNotBlank()) {
            Glass(Modifier.fillMaxWidth()) {
                Text(output, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
                TextButton(onClick = { clipboard.setText(AnnotatedString(output)) }) { Text("Copy code") }
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: AsarViewModel) {
    val p = vm.prefs
    val scope = rememberCoroutineScope()
    var key by remember { mutableStateOf(p.apiKey) }
    var showKey by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var model by remember { mutableStateOf(p.model) }
    var temp by remember { mutableFloatStateOf(p.temperature) }
    var rate by remember { mutableFloatStateOf(p.speechRate) }
    var nick by remember { mutableStateOf(p.nickname) }
    var prompt by remember { mutableStateOf(p.systemPrompt) }
    var lang by remember { mutableStateOf(p.lang) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Settings", fontSize = 22.sp, fontWeight = FontWeight.Bold)

        Glass {
            Text("Gemini API key", fontWeight = FontWeight.SemiBold)
            OutlinedTextField(
                value = key, onValueChange = { key = it }, singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = { showKey = !showKey }) { Text(if (showKey) "Hide" else "Show") }
                Button(onClick = { p.apiKey = key; status = "Key saved ❤️" }) { Text("Save") }
                OutlinedButton(onClick = {
                    status = "Testing…"
                    scope.launch {
                        status = try {
                            "✅ " + Gemini.chat(key, model, 0.5f, "Reply in one word: connected", listOf(Msg(true, "ping"))).take(60)
                        } catch (e: Exception) {
                            "❌ ${e.message}"
                        }
                    }
                }) { Text("Test") }
            }
            if (status.isNotBlank()) Text(status, color = Cyan)
        }

        Glass {
            Text("Model", fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("gemini-2.0-flash", "gemini-1.5-flash", "gemini-1.5-pro").forEach { m ->
                    FilterChip(selected = model == m, onClick = { model = m; p.model = m }, label = { Text(m, fontSize = 11.sp) })
                }
            }
            Text("Temperature: ${"%.1f".format(temp)}")
            Slider(value = temp, onValueChange = { temp = it; p.temperature = it }, valueRange = 0f..2f)
            Text("Speech speed: ${"%.1f".format(rate)}x")
            Slider(value = rate, onValueChange = { rate = it; p.speechRate = it }, valueRange = 0.5f..2f)
            Text("Voice language")
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("en-IN", "hi-IN").forEach { l ->
                    FilterChip(selected = lang == l, onClick = { lang = l; p.lang = l }, label = { Text(l) })
                }
            }
        }

        Glass {
            Text("Her personality", fontWeight = FontWeight.SemiBold)
            OutlinedTextField(
                value = nick, onValueChange = { nick = it; p.nickname = it },
                label = { Text("Nickname") }, singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = prompt, onValueChange = { prompt = it; p.systemPrompt = it },
                label = { Text("System prompt") }, minLines = 3, modifier = Modifier.fillMaxWidth()
            )
            TextButton(onClick = { prompt = DEFAULT_PROMPT; p.systemPrompt = DEFAULT_PROMPT }) { Text("Reset prompt") }
        }

        Glass {
            Text("Memory: ${p.memory.size} things remembered", fontWeight = FontWeight.SemiBold)
            Text(
                p.memory.joinToString("\n").ifBlank { "Say \"remember that …\" in chat to teach me." },
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { p.memory = emptyList(); status = "Memory cleared" }) { Text("Clear memory") }
                OutlinedButton(onClick = { vm.clearHistory(); status = "Chat cleared" }) { Text("Clear chat") }
            }
        }

        Glass {
            Text("About ASAR AI", fontWeight = FontWeight.SemiBold)
            Text(
                "Asar is your Jarvis-style AI companion, powered by Gemini. Your API key is stored encrypted on this device.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
