package com.asar.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AsarTheme { AsarApp() } }
    }
}

enum class Screen(val label: String) { Home("Home"), Chat("Chat"), Voice("Voice"), Coding("Coding"), Settings("Settings") }

@Composable
fun AsarApp(vm: AsarViewModel = viewModel()) {
    var screen by rememberSaveable { mutableStateOf(Screen.Home) }
    Scaffold(
        containerColor = Color.Black,
        bottomBar = {
            if (screen != Screen.Coding) {
                NavigationBar(containerColor = Color(0xFF07040D)) {
                    listOf(
                        Screen.Home to Icons.Filled.Home,
                        Screen.Chat to Icons.Filled.Send,
                        Screen.Voice to Icons.Filled.Notifications,
                        Screen.Settings to Icons.Filled.Settings
                    ).forEach { (s, icon) ->
                        NavigationBarItem(
                            selected = screen == s,
                            onClick = { screen = s },
                            icon = { Icon(icon, contentDescription = s.label) },
                            label = { Text(s.label) }
                        )
                    }
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (screen) {
                Screen.Home -> HomeScreen(vm) { screen = it }
                Screen.Chat -> ChatScreen(vm)
                Screen.Voice -> VoiceScreen(vm)
                Screen.Coding -> CodingScreen(vm) { screen = Screen.Home }
                Screen.Settings -> SettingsScreen(vm)
            }
        }
    }
}
